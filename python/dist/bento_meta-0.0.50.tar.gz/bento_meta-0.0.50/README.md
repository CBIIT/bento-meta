# bento_meta - Object Model for the Bento Metamodel Database

Read the docs at
[https://cbiit.github.io/bento-meta/](https://cbiit.github.io/bento-meta/).


