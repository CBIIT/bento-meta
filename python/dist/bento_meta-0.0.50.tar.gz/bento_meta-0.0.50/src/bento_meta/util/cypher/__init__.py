"""
bento_meta.util.cypher

Programmatically manipulate Cypher language constructs
"""
