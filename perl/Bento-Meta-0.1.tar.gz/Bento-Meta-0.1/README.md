# Bento Metamodel DB Tools

Install Bento::Meta:

    $ git clone https://github.com/CBIIT/bento-meta
    $ cd bento-meta/perl
    $ cpanm .

Note: some tests use Docker to set up a test database. Docker
containers should be cleaned up automatically after testing.

